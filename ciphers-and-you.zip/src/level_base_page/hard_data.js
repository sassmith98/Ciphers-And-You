export const hard_data = 
[
  {
    'val' : '1st hard task'
  },  
  
  {
    'val' : '2nd hard task'
  },

  {
    'val' : '3rd hard task'
  },
  
]