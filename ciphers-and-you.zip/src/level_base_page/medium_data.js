export const medium_data = 
[
  {
    'val' : '1st medium task'
  },  
  
  {
    'val' : '2nd medium task'
  },

  {
    'val' : '3rd medium task'
  },
  
]