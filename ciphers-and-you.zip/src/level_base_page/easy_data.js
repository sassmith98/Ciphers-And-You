export const easy_data = 
[
  {
    'val' : '1st easy task'
  },  
  
  {
    'val' : '2nd easy task'
  },

  {
    'val' : '3rd easy task'
  },
  
]